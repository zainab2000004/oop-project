import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VotingManagementSystem {
    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String DB_USER = "username";
    private static final String DB_PASSWORD = "password";

    // GUI components
    private static JFrame mainFrame;
    private static JPanel mainPanel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private static void createAndShowGUI() {
        mainFrame = new JFrame("Online Voting Management System");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(800, 600);

        mainPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton registerButton = new JButton("User Registration");
        JButton signInButton = new JButton("User Sign In");
        JButton adminLoginButton = new JButton("Admin Login");

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showRegistrationPanel();
            }
        });

        signInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignInPanel();
            }
        });

        adminLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAdminLoginPanel();
            }
        });

        mainPanel.add(registerButton);
        mainPanel.add(signInButton);
        mainPanel.add(adminLoginButton);

        mainFrame.add(mainPanel, BorderLayout.CENTER);
        mainFrame.setVisible(true);
    }

    private static void showRegistrationPanel() {
        mainPanel.removeAll();
        mainPanel.revalidate();
        mainPanel.repaint();

        JPanel registrationPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        registrationPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel userLabel = new JLabel("Username:");
        JTextField userField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel genderLabel = new JLabel("Gender:");
        JRadioButton maleRadio = new JRadioButton("Male");
        JRadioButton femaleRadio = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        JPanel genderPanel = new JPanel();
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        JLabel cnicLabel = new JLabel("CNIC:");
        JTextField cnicField = new JTextField();
        JLabel nationalityLabel = new JLabel("Nationality:");
        JTextField nationalityField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        JTextField ageField = new JTextField();
        JLabel idCardLabel = new JLabel("ID Card Number:");
        JTextField idCardField = new JTextField();
        JButton createAccountButton = new JButton("Create Account");

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passwordField.getPassword());
                String gender = maleRadio.isSelected() ? "Male" : "Female";
                String cnic = cnicField.getText();
                String nationality = nationalityField.getText();
                int age = Integer.parseInt(ageField.getText());
                String idCardNumber = idCardField.getText();

                if (!username.isEmpty() && !password.isEmpty() && !cnic.isEmpty() && !nationality.isEmpty() && !idCardNumber.isEmpty()) {
                    insertUserIntoDatabase(username, password, gender, cnic, nationality, age, idCardNumber);
                    JOptionPane.showMessageDialog(mainFrame, "Account created successfully!");
                } else {
                    JOptionPane.showMessageDialog(mainFrame, "Please fill in all fields.");
                }
            }
        });

        registrationPanel.add(userLabel);
        registrationPanel.add(userField);
        registrationPanel.add(passwordLabel);
        registrationPanel.add(passwordField);
        registrationPanel.add(genderLabel);
        registrationPanel.add(genderPanel);
        registrationPanel.add(cnicLabel);
        registrationPanel.add(cnicField);
        registrationPanel.add(nationalityLabel);
        registrationPanel.add(nationalityField);
        registrationPanel.add(ageLabel);
        registrationPanel.add(ageField);
        registrationPanel.add(idCardLabel);
        registrationPanel.add(idCardField);
        registrationPanel.add(createAccountButton);

        mainPanel.add(registrationPanel);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

    private static void insertUserIntoDatabase(String username, String password, String gender, String cnic, String nationality, int age, String idCardNumber) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "INSERT INTO user_accounts (username, password, gender, cnic, nationality, age, id_card_number) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, gender);
            statement.setString(4, cnic);
            statement.setString(5, nationality);
            statement.setInt(6, age);
            statement.setString(7, idCardNumber);

            statement.executeUpdate();

            statement.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(mainFrame, "Error: Account creation failed.");
        }
    }

    private static void showSignInPanel() {
        // Implement code to show sign-in panel
        JOptionPane.showMessageDialog(mainFrame, "Sign In Panel Placeholder");
    }

    private static void showAdminLoginPanel() {
        // Implement code to show admin login panel
        JOptionPane.showMessageDialog(mainFrame, "Admin Login Panel Placeholder");
    }
}
