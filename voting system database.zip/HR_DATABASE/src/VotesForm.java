import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class VotesForm {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JComboBox<String> candidateComboBox;
    private JTextField voteIdField;
    private JTextField voterIdField;
    private JTextField districtField;

    public VotesForm() {
        frame = new JFrame("Vote Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        // Initialize components
        voteIdField = new JTextField(10);
        voterIdField = new JTextField(10);
        districtField = new JTextField(20);

        // Fetch candidates from database and populate ComboBox
        candidateComboBox = new JComboBox<>();
        fetchCandidates(); // Method to populate candidates in ComboBox
        formPanel.add(new JLabel("Candidate:"));
        formPanel.add(candidateComboBox);

        formPanel.add(new JLabel("Vote ID:"));
        formPanel.add(voteIdField);
        formPanel.add(new JLabel("Voter ID:"));
        formPanel.add(voterIdField);
        formPanel.add(new JLabel("District:"));
        formPanel.add(districtField);

        JButton submitButton = new JButton("Submit");
        formPanel.add(new JLabel());  // Empty label to fill the grid
        formPanel.add(submitButton);

        // Generate a new vote ID and set it in the voteIdField
        voteIdField.setText(String.valueOf(generateVoteId()));

        frame.add(formPanel, BorderLayout.CENTER);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int voteId = Integer.parseInt(voteIdField.getText().trim());
                    int candidateId = getCandidateIdFromComboBox(); // Fetch selected candidate ID
                    int voterId = Integer.parseInt(voterIdField.getText().trim());
                    String district = districtField.getText().trim();

                    Connection conn = DriverManager.getConnection(url, user, pass);

                    // Check if vote_id already exists
                    String checkSql = "SELECT COUNT(*) FROM votes WHERE votes_id = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                    checkStmt.setInt(1, voteId);
                    ResultSet rs = checkStmt.executeQuery();
                    rs.next();
                    int count = rs.getInt(1);
                    rs.close();
                    checkStmt.close();

                    if (count > 0) {
                        JOptionPane.showMessageDialog(frame, "Error: Vote ID already exists.", "Insert Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        // Insert vote
                        String sql = "INSERT INTO votes (votes_id, candidate_id, voter_id, district, cast_time) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";
                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, voteId);
                        pstmt.setInt(2, candidateId);
                        pstmt.setInt(3, voterId);
                        pstmt.setString(4, district);

                        pstmt.executeUpdate();

                        pstmt.close();

                        JOptionPane.showMessageDialog(frame, "Vote inserted successfully!");
                    }

                    conn.close();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Error: ID fields must be numbers.", "Insert Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "SQL Error: " + ex.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.setVisible(true);
    }

    public VotesForm(int currentVoterId) {
		// TODO Auto-generated constructor stub
	}

	// Method to generate a new unique vote ID
    private int generateVoteId() {
        int newVoteId = 0;
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT MAX(votes_id) FROM votes";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                newVoteId = rs.getInt(1) + 1;
            } else {
                newVoteId = 1;
            }
            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Failed to generate new vote ID: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        return newVoteId;
    }

    // Method to fetch candidates from database and populate ComboBox
    private void fetchCandidates() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT candidate_id, party FROM candidate"; // Adjusted to fetch party instead of constitution
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int candidateId = rs.getInt("candidate_id");
                String party = rs.getString("party"); // Fetch party from database
                candidateComboBox.addItem(candidateId + " - " + party);
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Failed to fetch candidates: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to get the selected candidate ID from ComboBox
    private int getCandidateIdFromComboBox() {
        String selectedCandidate = (String) candidateComboBox.getSelectedItem();
        // Extract candidate ID from selected string (assuming format: "id - party")
        String candidateIdStr = selectedCandidate.split(" ")[0]; // Split by space and get first part (id)
        return Integer.parseInt(candidateIdStr);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VotesForm();
            }
        });
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }
}
