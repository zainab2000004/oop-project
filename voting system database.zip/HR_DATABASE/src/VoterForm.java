import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class VoterForm {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private int currentVoterId = -1; // To store the logged-in voter's ID

    public VoterForm() {
        frame = new JFrame("Voter Login / Signup");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Panel for login and signup buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Signup");

        buttonPanel.add(loginButton);
        buttonPanel.add(signupButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.add(mainPanel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showLoginPanel();
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignupPanel();
            }
        });

        frame.setVisible(true);
    }

    private void showLoginPanel() {
        clearFrame();

        JPanel loginPanel = new JPanel(new GridLayout(0, 2));

        JTextField voterIdField = new JTextField(10);
        JPasswordField passwordField = new JPasswordField(20);

        loginPanel.add(new JLabel("Voter ID:"));
        loginPanel.add(voterIdField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);

        JButton loginButton = new JButton("Login");

        loginPanel.add(new JLabel());  // Empty label to fill the grid
        loginPanel.add(loginButton);

        frame.add(loginPanel, BorderLayout.CENTER);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int voterId = Integer.parseInt(voterIdField.getText().trim());
                    String password = new String(passwordField.getPassword()).trim();

                    if (validateLogin(voterId, password)) {
                        currentVoterId = voterId; // Store the current voter's ID
                        JOptionPane.showMessageDialog(null, "Login successful. Welcome Voter ID: " + voterId);
                        showVoteButtons(); // Show the voting buttons
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Voter ID or Password. Please try again.",
                                "Login Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Error: Voter ID must be a number.", "Login Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "SQL Error: " + ex.getMessage(), "Login Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.revalidate();
        frame.repaint();
    }

    private void showSignupPanel() {
        clearFrame();

        JPanel signupPanel = new JPanel(new GridLayout(0, 2));

        JTextField voterIdField = new JTextField(10);
        JPasswordField passwordField = new JPasswordField(20);
        JTextField constitutionField = new JTextField(20);
        JTextField loginIdField = new JTextField(20);
        JTextField dobField = new JTextField(10);
        JTextField genderField = new JTextField(10);
        JTextField nameField = new JTextField(20);

        signupPanel.add(new JLabel("Voter ID:"));
        signupPanel.add(voterIdField);
        signupPanel.add(new JLabel("Password:"));
        signupPanel.add(passwordField);
        signupPanel.add(new JLabel("Constitution:"));
        signupPanel.add(constitutionField);
        signupPanel.add(new JLabel("Login ID:"));
        signupPanel.add(loginIdField);
        signupPanel.add(new JLabel("DOB (YYYY-MM-DD):"));
        signupPanel.add(dobField);
        signupPanel.add(new JLabel("Gender:"));
        signupPanel.add(genderField);
        signupPanel.add(new JLabel("Name:"));
        signupPanel.add(nameField);

        JButton signupButton = new JButton("Signup");

        signupPanel.add(new JLabel());  // Empty label to fill the grid
        signupPanel.add(signupButton);

        frame.add(signupPanel, BorderLayout.CENTER);

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int voterId = Integer.parseInt(voterIdField.getText().trim());
                    String password = new String(passwordField.getPassword()).trim();
                    String constitution = constitutionField.getText().trim();
                    String loginId = loginIdField.getText().trim();
                    Date dob = Date.valueOf(dobField.getText().trim());
                    String gender = genderField.getText().trim();
                    String name = nameField.getText().trim();

                    if (validateVoterId(voterId)) {
                        insertNewVoter(voterId, password, constitution, loginId, dob, gender, name);
                        currentVoterId = voterId; // Store the current voter's ID
                        JOptionPane.showMessageDialog(null, "Signup successful. Welcome Voter ID: " + voterId);
                        showVoteButtons(); // Show the voting buttons
                    } else {
                        JOptionPane.showMessageDialog(null, "Error: Voter ID already exists or is invalid. Please choose another ID.",
                                "Signup Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Error: Voter ID must be a number.", "Signup Error", JOptionPane.ERROR_MESSAGE);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(null, "Error: Invalid date format (YYYY-MM-DD).", "Signup Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "SQL Error: " + ex.getMessage(), "Signup Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.revalidate();
        frame.repaint();
    }

    private void showVoteButtons() {
        clearFrame();

        JPanel buttonPanel = new JPanel();

        JButton castVoteButton = new JButton("Cast Vote");
        JButton exitButton = new JButton("Exit");

        buttonPanel.add(castVoteButton);
        buttonPanel.add(exitButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        castVoteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open VotesForm when Cast Vote button is clicked
                new VotesForm().setVisible(true);
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exit the application
            }
        });

        frame.revalidate();
        frame.repaint();
    }

    private boolean validateLogin(int voterId, String password) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM voter WHERE voter_id = ? AND password = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, voterId);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();
            return rs.next(); // Return true if a matching record is found
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }

    private boolean validateVoterId(int voterId) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT COUNT(*) FROM voter WHERE voter_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, voterId);
            rs = pstmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            return count == 0; // Return true if the voter ID does not exist in the database
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }

    private void insertNewVoter(int voterId, String password, String constitution, String loginId, Date dob, String gender, String name) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DriverManager.getConnection(url, user, pass);
            String sql = "INSERT INTO voter (voter_id, password, constitution, login_id, dob, gender, name) VALUES (?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, voterId);
            pstmt.setString(2, password);
            pstmt.setString(3, constitution);
            pstmt.setString(4, loginId);
            pstmt.setDate(5, dob);
            pstmt.setString(6, gender);
            pstmt.setString(7, name);

            pstmt.executeUpdate();

        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }

    private void clearFrame() {
        frame.getContentPane().removeAll();
        frame.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VoterForm();
            }
        });
    }
}
