import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class CandidateTableGui {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public CandidateTableGui() {
        frame = new JFrame("Candidate Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        model = new DefaultTableModel();
        table = new JTable();
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton insertButton = new JButton("Insert");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(insertButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInsertForm();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateRow();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteRow();
            }
        });

        populateTable();

        frame.setVisible(true);
    }

    private void populateTable() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM candidate";
            ResultSet rs = stmt.executeQuery(sql);

            // Get column names
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            Vector<String> columnNames = new Vector<>(columnCount);
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            // Get all rows
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>(columnCount);
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    row.add(rs.getObject(columnIndex));
                }
                data.add(row);
            }

            model.setDataVector(data, columnNames);

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
        }
    }

    private void showInsertForm() {
        JTextField candidateIdField = new JTextField(10);
        JTextField constitutionField = new JTextField(20);
        JTextField genderField = new JTextField(10);
        JTextField partyField = new JTextField(20);
        JTextField statusField = new JTextField(20);
        JTextField ageField = new JTextField(5);
        JTextField symbolField = new JTextField(10);

        JPanel insertPanel = new JPanel(new GridLayout(0, 2));
        insertPanel.add(new JLabel("Candidate ID:"));
        insertPanel.add(candidateIdField);
        insertPanel.add(new JLabel("Constitution:"));
        insertPanel.add(constitutionField);
        insertPanel.add(new JLabel("Gender:"));
        insertPanel.add(genderField);
        insertPanel.add(new JLabel("Party:"));
        insertPanel.add(partyField);
        insertPanel.add(new JLabel("Status:"));
        insertPanel.add(statusField);
        insertPanel.add(new JLabel("Age:"));
        insertPanel.add(ageField);
        insertPanel.add(new JLabel("Symbol:"));
        insertPanel.add(symbolField);

        int option = JOptionPane.showConfirmDialog(frame, insertPanel, "Insert Candidate", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int candidateId = Integer.parseInt(candidateIdField.getText().trim());
                String constitution = constitutionField.getText().trim();
                String gender = genderField.getText().trim();
                String party = partyField.getText().trim();
                String status = statusField.getText().trim();
                int age = Integer.parseInt(ageField.getText().trim());
                String symbol = symbolField.getText().trim();

                Connection conn = DriverManager.getConnection(url, user, pass);
                String sql = "INSERT INTO candidate (candidate_id, constitution, gender, party, status, age, symbol) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, candidateId);
                pstmt.setString(2, constitution);
                pstmt.setString(3, gender);
                pstmt.setString(4, party);
                pstmt.setString(5, status);
                pstmt.setInt(6, age);
                pstmt.setString(7, symbol);

                pstmt.executeUpdate();

                pstmt.close();
                conn.close();

                populateTable(); // Refresh table display
            } catch (NumberFormatException | SQLException e) {
                JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to update.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(url, user, pass);

            int candidateId = (int) model.getValueAt(selectedRow, 0); // Assuming candidate_id is INT
            String constitution = JOptionPane.showInputDialog(frame, "Enter Constitution:", model.getValueAt(selectedRow, 1));
            String gender = JOptionPane.showInputDialog(frame, "Enter Gender:", model.getValueAt(selectedRow, 2));
            String party = JOptionPane.showInputDialog(frame, "Enter Party:", model.getValueAt(selectedRow, 3));
            String status = JOptionPane.showInputDialog(frame, "Enter Status:", model.getValueAt(selectedRow, 4));
            int age = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter Age:", model.getValueAt(selectedRow, 5).toString())); // Convert to String first
            String symbol = JOptionPane.showInputDialog(frame, "Enter Symbol:", model.getValueAt(selectedRow, 6));

            String sql = "UPDATE candidate SET constitution=?, gender=?, party=?, status=?, age=?, symbol=? WHERE candidate_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, constitution);
            pstmt.setString(2, gender);
            pstmt.setString(3, party);
            pstmt.setString(4, status);
            pstmt.setInt(5, age);
            pstmt.setString(6, symbol);
            pstmt.setInt(7, candidateId);

            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
            return;
        }

        try {
            int candidateId = (int) model.getValueAt(selectedRow, 0);

            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM candidate WHERE candidate_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, candidateId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Candidate deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to delete candidate.");
            }

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CandidateTableGui();
            }
        });
    }
}
