import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class AdminForm {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JPanel tablePanel;
    private JTable adminTable;

    public AdminForm() {
        frame = new JFrame("Admin Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // Show initial message dialog
        showInitialDialog();

        frame.setVisible(true);
    }

    private void showInitialDialog() {
        JOptionPane.showMessageDialog(frame,
                "Only admins can see and manage admin records.",
                "Admin Access Required",
                JOptionPane.INFORMATION_MESSAGE);

        // Prompt for admin login
        boolean isAdmin = showAdminLoginDialog();
        if (isAdmin) {
            initializeAdminInterface();
        } else {
            JOptionPane.showMessageDialog(frame, "Incorrect admin credentials. Exiting application.",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    private boolean showAdminLoginDialog() {
        JPanel panel = new JPanel(new GridLayout(0, 1));
        JLabel descriptionLabel = new JLabel("Please enter admin credentials to access:");
        JTextField usernameField = new JTextField(10);
        JPasswordField passwordField = new JPasswordField(10);

        panel.add(descriptionLabel);
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        int option = JOptionPane.showConfirmDialog(frame, panel, "Admin Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            return validateAdminCredentials(username, password);
        }
        return false;
    }

    private boolean validateAdminCredentials(String username, String password) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT COUNT(*) FROM admin WHERE username = ? AND password = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            rs.next();
            boolean isValid = rs.getInt(1) > 0;

            rs.close();
            pstmt.close();
            conn.close();

            return isValid;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
            return false;
        }
    }

    private void initializeAdminInterface() {
        // Create table panel
        tablePanel = new JPanel(new BorderLayout());

        // Create table
        adminTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(adminTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Add buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel addPanel = new JPanel(new GridLayout(0, 1));
                JTextField adminIdField = new JTextField(10); // Admin ID field
                JTextField usernameField = new JTextField(10);
                JPasswordField passwordField = new JPasswordField(10);

                addPanel.add(new JLabel("Admin ID:")); // Label for admin ID
                addPanel.add(adminIdField); // Admin ID input field
                addPanel.add(new JLabel("Username:"));
                addPanel.add(usernameField);
                addPanel.add(new JLabel("Password:"));
                addPanel.add(passwordField);

                int result = JOptionPane.showConfirmDialog(frame, addPanel,
                        "Enter new admin details", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    String adminId = adminIdField.getText().trim(); // Get admin ID
                    String username = usernameField.getText().trim();
                    String password = new String(passwordField.getPassword()).trim();
                    if (!adminId.isEmpty() && !username.isEmpty() && !password.isEmpty()) {
                        addAdmin(adminId, username, password); // Pass admin ID to addAdmin method
                        refreshAdminTable();
                    } else {
                        JOptionPane.showMessageDialog(frame, "Admin ID, username, and password cannot be empty.");
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = adminTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to update.");
                    return;
                }
                String currentUsername = (String) adminTable.getValueAt(selectedRow, 0);
                String newUsername = JOptionPane.showInputDialog(frame, "Enter new username:", currentUsername);
                String newPassword = JOptionPane.showInputDialog(frame, "Enter new password:");
                if (newUsername != null && newPassword != null && !newUsername.trim().isEmpty() && !newPassword.trim().isEmpty()) {
                    updateAdmin(currentUsername, newUsername.trim(), newPassword.trim());
                    refreshAdminTable();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid username or password. Try again.");
                }
            }
        });
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = adminTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
                    return;
                }
                String username = (String) adminTable.getValueAt(selectedRow, 0);
                int confirmDialog = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete admin '" + username + "'?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirmDialog == JOptionPane.YES_OPTION) {
                    deleteAdmin(username);
                    refreshAdminTable();
                }
            }
        });
        buttonPanel.add(deleteButton);

        frame.add(tablePanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Load admin table on startup
        refreshAdminTable();

        frame.revalidate();
        frame.repaint();
    }

    private void refreshAdminTable() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM admin";
            ResultSet rs = stmt.executeQuery(sql);

            // Get column names
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            Vector<String> columnNames = new Vector<>();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
            }

            // Get all rows
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                data.add(row);
            }

            DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
            adminTable.setModel(tableModel);

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
        }
    }

    private void addAdmin(String adminId, String username, String password) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "INSERT INTO admin (admin_id, username, password) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, adminId);
            pstmt.setString(2, username);
            pstmt.setString(3, password);

            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            JOptionPane.showMessageDialog(frame, "Admin added successfully!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + ex.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateAdmin(String currentUsername, String newUsername, String newPassword) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "UPDATE admin SET username = ?, password = ? WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newUsername);
            pstmt.setString(2, newPassword);
            pstmt.setString(3, currentUsername);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Admin updated successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Update failed. Admin not found.");
            }

            pstmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + ex.getMessage(), "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteAdmin(String username) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM admin WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Admin deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Delete failed. Admin not found.");
            }

            pstmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + ex.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminForm();
            }
        });
    }
}
