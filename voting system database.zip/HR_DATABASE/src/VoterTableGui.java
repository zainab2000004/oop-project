import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Vector;

public class VoterTableGui {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public VoterTableGui() {
        frame = new JFrame("Voter Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        model = new DefaultTableModel();
        table = new JTable();
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton insertButton = new JButton("Insert");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(insertButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInsertForm();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateRow();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteRow();
            }
        });

        populateTable();

        frame.setVisible(true);
    }

    private void populateTable() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM voter";
            ResultSet rs = stmt.executeQuery(sql);

            // Get column names
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            Vector<String> columnNames = new Vector<>(columnCount);
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            // Get all rows
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>(columnCount);
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    if (metaData.getColumnType(columnIndex) == Types.DATE) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        row.add(dateFormat.format(rs.getDate(columnIndex)));
                    } else {
                        row.add(rs.getObject(columnIndex));
                    }
                }
                data.add(row);
            }

            model.setDataVector(data, columnNames);

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
        }
    }

    private void showInsertForm() {
        JTextField voterIdField = new JTextField(10);
        JTextField constitutionField = new JTextField(20);
        JTextField loginIdField = new JTextField(20);
        JTextField dobField = new JTextField(10);
        JTextField genderField = new JTextField(10);
        JTextField nameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        JPanel insertPanel = new JPanel(new GridLayout(0, 2));
        insertPanel.add(new JLabel("Voter ID:"));
        insertPanel.add(voterIdField);
        insertPanel.add(new JLabel("Constitution:"));
        insertPanel.add(constitutionField);
        insertPanel.add(new JLabel("Login ID:"));
        insertPanel.add(loginIdField);
        insertPanel.add(new JLabel("DOB (YYYY-MM-DD):"));
        insertPanel.add(dobField);
        insertPanel.add(new JLabel("Gender:"));
        insertPanel.add(genderField);
        insertPanel.add(new JLabel("Name:"));
        insertPanel.add(nameField);
        insertPanel.add(new JLabel("Password:"));
        insertPanel.add(passwordField);

        int option = JOptionPane.showConfirmDialog(frame, insertPanel, "Insert Voter", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int voterId = Integer.parseInt(voterIdField.getText().trim());
                String constitution = constitutionField.getText().trim();
                String loginId = loginIdField.getText().trim();
                Date dob = Date.valueOf(dobField.getText().trim());
                String gender = genderField.getText().trim();
                String name = nameField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();

                Connection conn = DriverManager.getConnection(url, user, pass);
                String sql = "INSERT INTO voter (voter_id, constitution, login_id, dob, gender, name, password) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, voterId);
                pstmt.setString(2, constitution);
                pstmt.setString(3, loginId);
                pstmt.setDate(4, dob);
                pstmt.setString(5, gender);
                pstmt.setString(6, name);
                pstmt.setString(7, password);

                pstmt.executeUpdate();

                pstmt.close();
                conn.close();

                populateTable(); // Refresh table display
            } catch (NumberFormatException | SQLException e) {
                JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to update.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(url, user, pass);

            int voterId = (int) model.getValueAt(selectedRow, 0); // Assuming voter_id is INT
            String constitution = JOptionPane.showInputDialog(frame, "Enter Constitution:", model.getValueAt(selectedRow, 1));
            String loginId = JOptionPane.showInputDialog(frame, "Enter Login ID:", model.getValueAt(selectedRow, 2));
            Date dob = Date.valueOf(JOptionPane.showInputDialog(frame, "Enter DOB (YYYY-MM-DD):", model.getValueAt(selectedRow, 3)));
            String gender = JOptionPane.showInputDialog(frame, "Enter Gender:", model.getValueAt(selectedRow, 4));
            String name = JOptionPane.showInputDialog(frame, "Enter Name:", model.getValueAt(selectedRow, 5));
            String password = JOptionPane.showInputDialog(frame, "Enter Password:", model.getValueAt(selectedRow, 6));

            String sql = "UPDATE voter SET constitution=?, login_id=?, dob=?, gender=?, name=?, password=? WHERE voter_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, constitution);
            pstmt.setString(2, loginId);
            pstmt.setDate(3, dob);
            pstmt.setString(4, gender);
            pstmt.setString(5, name);
            pstmt.setString(6, password);
            pstmt.setInt(7, voterId);

            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
            return;
        }

        try {
            int voterId = (int) model.getValueAt(selectedRow, 0);

            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM voter WHERE voter_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, voterId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Voter deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to delete voter.");
            }

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VoterTableGui();
            }
        });
    }
}
