import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class AdminTableGui {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public AdminTableGui() {
        frame = new JFrame("Admin Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        model = new DefaultTableModel();
        table = new JTable();
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton insertButton = new JButton("Insert");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(insertButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInsertForm();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateRow();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteRow();
            }
        });

        populateTable();

        frame.setVisible(true);
    }

    private void populateTable() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM admin";
            ResultSet rs = stmt.executeQuery(sql);

            // Get column names
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            Vector<String> columnNames = new Vector<>(columnCount);
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            // Get all rows
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>(columnCount);
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    row.add(rs.getObject(columnIndex));
                }
                data.add(row);
            }

            model.setDataVector(data, columnNames);

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
        }
    }

    private void showInsertForm() {
        JTextField adminIdField = new JTextField(10);
        JTextField passwordField = new JTextField(20);
        JTextField userRegistrationField = new JTextField(20);
        JTextField usernameField = new JTextField(20);

        JPanel insertPanel = new JPanel(new GridLayout(0, 2));
        insertPanel.add(new JLabel("Admin ID:"));
        insertPanel.add(adminIdField);
        insertPanel.add(new JLabel("Password:"));
        insertPanel.add(passwordField);
        insertPanel.add(new JLabel("User Registration (YYYY-MM-DD HH:MM:SS):"));
        insertPanel.add(userRegistrationField);
        insertPanel.add(new JLabel("Username:"));
        insertPanel.add(usernameField);

        int option = JOptionPane.showConfirmDialog(frame, insertPanel, "Insert Admin", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int adminId = Integer.parseInt(adminIdField.getText().trim());
                String password = passwordField.getText().trim();
                Timestamp userRegistration = Timestamp.valueOf(userRegistrationField.getText().trim());
                String username = usernameField.getText().trim();

                Connection conn = DriverManager.getConnection(url, user, pass);
                String sql = "INSERT INTO admin (admin_id, password, user_registration, username) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, adminId);
                pstmt.setString(2, password);
                pstmt.setTimestamp(3, userRegistration);
                pstmt.setString(4, username);

                pstmt.executeUpdate();

                pstmt.close();
                conn.close();

                populateTable(); // Refresh table display
            } catch (SQLException | IllegalArgumentException e) {
                JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to update.");
            return;
        }

        try {
            int adminId = (int) model.getValueAt(selectedRow, 0); // Assuming admin_id is INT
            String password = JOptionPane.showInputDialog(frame, "Enter Password:", model.getValueAt(selectedRow, 1));
            Timestamp userRegistration = Timestamp.valueOf(JOptionPane.showInputDialog(frame, "Enter User Registration (YYYY-MM-DD HH:MM:SS):", model.getValueAt(selectedRow, 2)));
            String username = JOptionPane.showInputDialog(frame, "Enter Username:", model.getValueAt(selectedRow, 3));

            Connection conn = DriverManager.getConnection(url, user, pass);

            String sql = "UPDATE admin SET password=?, user_registration=?, username=? WHERE admin_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, password);
            pstmt.setTimestamp(2, userRegistration);
            pstmt.setString(3, username);
            pstmt.setInt(4, adminId);

            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
            return;
        }

        try {
            int adminId = (int) model.getValueAt(selectedRow, 0);

            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM admin WHERE admin_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, adminId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Admin deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to delete admin.");
            }

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminTableGui();
            }
        });
    }
}
