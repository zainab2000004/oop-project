import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class VotesTableGui {
    private static final String url = "jdbc:oracle:thin:@192.168.10.8:1521:XE";
    private static final String user = "admin";  // Updated username
    private static final String pass = "oracle"; // Updated password

    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public VotesTableGui() {
        frame = new JFrame("Votes Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        model = new DefaultTableModel();
        table = new JTable();
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton insertButton = new JButton("Insert");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(insertButton);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInsertForm();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteRow();
            }
        });

        populateTable();

        frame.setVisible(true);
    }

    private void populateTable() {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM votes";
            ResultSet rs = stmt.executeQuery(sql);

            // Get column names
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            Vector<String> columnNames = new Vector<>(columnCount);
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            // Get all rows
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>(columnCount);
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    row.add(rs.getObject(columnIndex));
                }
                data.add(row);
            }

            model.setDataVector(data, columnNames);

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage());
        }
    }

    private void showInsertForm() {
        JTextField votesIdField = new JTextField(10);
        JTextField candidateIdField = new JTextField(10);
        JTextField voterIdField = new JTextField(10);
        JTextField districtField = new JTextField(20);

        JPanel insertPanel = new JPanel(new GridLayout(0, 2));
        insertPanel.add(new JLabel("Votes ID:"));
        insertPanel.add(votesIdField);
        insertPanel.add(new JLabel("Candidate ID:"));
        insertPanel.add(candidateIdField);
        insertPanel.add(new JLabel("Voter ID:"));
        insertPanel.add(voterIdField);
        insertPanel.add(new JLabel("District:"));
        insertPanel.add(districtField);

        int option = JOptionPane.showConfirmDialog(frame, insertPanel, "Insert Votes", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int votesId = Integer.parseInt(votesIdField.getText().trim());
                int candidateId = Integer.parseInt(candidateIdField.getText().trim());
                int voterId = Integer.parseInt(voterIdField.getText().trim());
                String district = districtField.getText().trim();

                Connection conn = DriverManager.getConnection(url, user, pass);
                String sql = "INSERT INTO votes (votes_id, candidate_id, voter_id, district) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, votesId);
                pstmt.setInt(2, candidateId);
                pstmt.setInt(3, voterId);
                pstmt.setString(4, district);

                pstmt.executeUpdate();

                pstmt.close();
                conn.close();

                populateTable(); // Refresh table display
            } catch (NumberFormatException | SQLException e) {
                JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
            return;
        }

        try {
            int votesId = (int) model.getValueAt(selectedRow, 0);

            Connection conn = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM votes WHERE votes_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, votesId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Votes entry deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to delete votes entry.");
            }

            pstmt.close();
            conn.close();

            populateTable(); // Refresh table display
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "SQL Error: " + e.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VotesTableGui();
            }
        });
    }
}
