package com.hr.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import com.hr.bean.Admin;
import com.hr.util.DBUtil;

public class AdminDao {

    public ArrayList<Admin> getAllAdmins() throws Exception {
        ArrayList<Admin> list = new ArrayList<>();
        String sql = "SELECT * FROM admin";
        ResultSet rs = null;

        try {
            rs = DBUtil.executeQuery(sql);

            while (rs.next()) {
                Admin admin = new Admin();
                admin.setAdminId(rs.getInt("ADMIN_ID")); // Matches column name in SQL
                admin.setPassword(rs.getString("PASSWORD")); // Matches column name in SQL
                admin.setUserRegistration(rs.getTimestamp("USER_REGISTRATION")); // Matches column name in SQL
                admin.setUsername(rs.getString("USERNAME")); // Matches column name in SQL
                list.add(admin);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            DBUtil.closeConnection(); // Close connection after use
        }

        return list;
    }
}
