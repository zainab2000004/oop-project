package com.hr.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import com.hr.bean.Voter;
import com.hr.util.DBUtil;

public class VoterDao {

    public ArrayList<Voter> getAllVoters() throws Exception {
        ArrayList<Voter> list = new ArrayList<>();
        String sql = "SELECT * FROM voter";
        ResultSet rs = DBUtil.executeQuery(sql);

        try {
            while (rs.next()) {
                Voter voter = new Voter();
                voter.setVoterId(rs.getInt("voter_id"));
                voter.setConstitution(rs.getString("constitution"));
                voter.setLoginId(rs.getString("login_id"));
                voter.setDob(rs.getDate("DOB"));
                voter.setGender(rs.getString("gender"));
                voter.setName(rs.getString("name"));
                voter.setPassword(rs.getString("password"));
                list.add(voter);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            DBUtil.closeConnection(); // Close connection after use
        }

        return list;
    }
}
