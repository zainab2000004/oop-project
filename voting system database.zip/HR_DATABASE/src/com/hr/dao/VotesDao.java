package com.hr.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import com.hr.bean.Votes;
import com.hr.util.DBUtil;

public class VotesDao {

    public ArrayList<Votes> getAllVotes() throws Exception {
        ArrayList<Votes> list = new ArrayList<>();
        String sql = "SELECT * FROM votes";
        ResultSet rs = DBUtil.executeQuery(sql);

        try {
            while (rs.next()) {
                Votes votes = new Votes();
                votes.setVotesId(rs.getInt("votes_id"));
                votes.setCandidateId(rs.getInt("candidate_id"));
                votes.setVoterId(rs.getInt("voter_id"));
                votes.setDistrict(rs.getString("district"));
                votes.setCastTime(rs.getTimestamp("cast_time"));
                list.add(votes);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            DBUtil.closeConnection(); // Close connection after use
        }

        return list;
    }
}
