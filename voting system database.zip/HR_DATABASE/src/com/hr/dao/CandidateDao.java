package com.hr.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import com.hr.bean.Candidate;
import com.hr.util.DBUtil;

public class CandidateDao{

    public ArrayList<Candidate> getAllCandidates() throws Exception {
        ArrayList<Candidate> list = new ArrayList<>();
        String sql = "SELECT * FROM candidate";
        ResultSet rs = DBUtil.executeQuery(sql);
        
        try {
            while (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setCANDIDATE_ID(rs.getInt("CANDIDATE_ID"));
                candidate.setConstitution(rs.getString("constitution"));
                candidate.setGender(rs.getString("gender"));
                candidate.setParty(rs.getString("party"));
                candidate.setStatus(rs.getString("status"));
                candidate.setSymbol(rs.getString("symbol"));
                candidate.setAge(rs.getInt("age"));
                list.add(candidate);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            DBUtil.closeConnection(); // Close connection after use
        }
        
        return list;
    }
}
