package com.hr.bean;

import java.sql.Timestamp;

public class Votes {
    private int votesId;
    private int candidateId;
    private int voterId;
    private String district;
    private Timestamp castTime;

    public int getVotesId() {
        return votesId;
    }

    public void setVotesId(int votesId) {
        this.votesId = votesId;
    }

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getVoterId() {
        return voterId;
    }

    public void setVoterId(int voterId) {
        this.voterId = voterId;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public Timestamp getCastTime() {
        return castTime;
    }

    public void setCastTime(Timestamp castTime) {
        this.castTime = castTime;
    }
}
