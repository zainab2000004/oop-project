package com.hr.bean;

import java.sql.Timestamp;

public class Admin {
    private int adminId;
    private String password;
    private Timestamp userRegistration;
    private String username; // Added field for username

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getUserRegistration() {
        return userRegistration;
    }

    public void setUserRegistration(Timestamp userRegistration) {
        this.userRegistration = userRegistration;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
