package com.hr.bean;

public class Candidate {
    private int CANDIDATE_ID;
    private String constitution;
    private String gender;
    private String party;
    private String status;
    private String symbol;
    private int age;

    public int getCANDIDATE_ID() {
        return CANDIDATE_ID;
    }

    public void setCANDIDATE_ID(int CANDIDATE_ID) {
        this.CANDIDATE_ID = CANDIDATE_ID;
    }

    public String getConstitution() {
        return constitution;
    }

    public void setConstitution(String constitution) {
        this.constitution = constitution;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
