package com.hr.test;

import java.util.ArrayList;
import com.hr.bean.Votes;
import com.hr.dao.VotesDao;

public class VotesTest {

    public static void main(String[] args) {
        VotesDao votesDao = new VotesDao();

        try {
            ArrayList<Votes> votes = votesDao.getAllVotes();

            for (Votes vote : votes) {
                System.out.println("Votes ID: " + vote.getVotesId());
                System.out.println("Candidate ID: " + vote.getCandidateId());
                System.out.println("Voter ID: " + vote.getVoterId());
                System.out.println("District: " + vote.getDistrict());
                System.out.println("Cast Time: " + vote.getCastTime());
                System.out.println("--------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
