package com.hr.test;

import java.util.ArrayList;

import com.hr.bean.Candidate;
import com.hr.dao.CandidateDao;

public class Test {

    public static void main(String[] args) {
        CandidateDao candidateDao = new CandidateDao();

        try {
            ArrayList<Candidate> candidates = candidateDao.getAllCandidates();

            for (Candidate candidate : candidates) {
                System.out.println("Candidate ID: " + candidate.getCANDIDATE_ID());
                System.out.println("Constitution: " + candidate.getConstitution());
                System.out.println("Gender: " + candidate.getGender());
                System.out.println("Party: " + candidate.getParty());
                System.out.println("Status: " + candidate.getStatus());
                System.out.println("Symbol: " + candidate.getSymbol());
                System.out.println("Age: " + candidate.getAge());
                System.out.println("--------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
