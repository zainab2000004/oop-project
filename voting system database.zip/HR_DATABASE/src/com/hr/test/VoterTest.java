package com.hr.test;

import java.util.ArrayList;
import com.hr.bean.Voter;
import com.hr.dao.VoterDao;

public class VoterTest {

    public static void main(String[] args) {
        VoterDao voterDao = new VoterDao();

        try {
            ArrayList<Voter> voters = voterDao.getAllVoters();

            for (Voter voter : voters) {
                System.out.println("Voter ID: " + voter.getVoterId());
                System.out.println("Constitution: " + voter.getConstitution());
                System.out.println("Login ID: " + voter.getLoginId());
                System.out.println("Date of Birth: " + voter.getDob());
                System.out.println("Gender: " + voter.getGender());
                System.out.println("Name: " + voter.getName());
                System.out.println("Password: " + voter.getPassword());
                System.out.println("--------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
